from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/weight")
def weight():
    peso = request.args.get('peso', type=int)
    return render_template("weight.html", peso=peso)

@app.route("/height")
def height():
    altura = request.args.get('altura', type=int)
    return render_template("height.html", altura=altura)

# Página de resultados donde se calculan el IMC
@app.route("/result")
def result():
    peso = request.args.get('peso', type=int)
    altura = request.args.get('altura', type=int)
    if peso is not None and altura is not None:
        imc = peso / ((altura / 100) ** 2)  # Fórmula de IMC
        # Categorización del IMC
        if imc < 18.5:
            categoria = "Bajo peso"
            recomendacion = "Es recomendable consultar con un nutricionista para aumentar tu ingesta calórica."
        elif 18.5 <= imc < 24.9:
            categoria = "Normal"
            recomendacion = "Mantén tu estilo de vida saludable."
        elif 25 <= imc < 29.9:
            categoria = "Sobrepeso"
            recomendacion = "Considera incorporar ejercicio físico a tu rutina y consultar con un especialista."
        else:
            categoria = "Obesidad"
            recomendacion = "Es importante hablar con un médico para un plan de pérdida de peso y mejorar tu salud."
        
        return render_template("result.html", imc=imc, categoria=categoria, recomendacion=recomendacion)
    else:
        return "Datos incompletos"

@app.route("/categorias")
def categorias():
    return render_template("categorias.html")

@app.route("/entretenimiento")
def entretenimiento():
    return render_template("entretenimiento.html", category="entretenimiento")

@app.route("/deporte")
def deporte():
    return render_template("deporte.html", category="deporte")

@app.route("/geografia")
def geografia():
    return render_template("geografia.html", category="geografia")

@app.route("/ciencia")
def ciencia():
    return render_template("ciencia.html", category="ciencia")

@app.route("/historia")
def historia():
    return render_template("historia.html", category="historia")

@app.route("/arte")
def arte():
    return render_template("arte.html", category="arte")

app.run(debug=True)
